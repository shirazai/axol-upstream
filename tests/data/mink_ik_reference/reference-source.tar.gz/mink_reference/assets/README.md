# Frozen Axol model reference

The model and meshes are pinned inputs to the independent numerical solver.
The model root has zero yaw; the public Axol world frame differs by a fixed
rotation about the root origin. The URDF and mesh bytes are preserved from
the source revision recorded in the fixture provenance, with the URDF file
renamed to `axol_mink.urdf`. Keep the mesh license with these assets.
