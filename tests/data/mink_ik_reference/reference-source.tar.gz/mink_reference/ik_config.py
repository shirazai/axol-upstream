"""Independent frozen Axol numerical reference; see the fixture README."""

from __future__ import annotations
import math
from dataclasses import dataclass
from pathlib import Path
PINNED_URDF: Path = Path(__file__).resolve().parent / 'assets' / 'axol_mink.urdf'
SERVING_STEP_BUDGET_RAD: float = 0.0055 * 2 * math.pi

@dataclass
class MinkIKConfig:
    mink_position_cost: float = 1.0
    mink_orientation_cost: float = 0.25
    mink_elbow_cost: float = 0.0
    mink_posture_cost: float = 0.05
    mink_posture_speed_gate: float = 0.15
    mink_posture_gate_tau: float = 1.0
    mink_posture_target: str = 'rest'
    mink_lm_damping: float = 0.01
    mink_damping: float = 0.8
    mink_iterations: int = 4
    mink_dt: float = 1.0
    mink_collision: bool = True
    mink_collision_min_distance: float = 0.01
    mink_collision_detection_distance: float = 0.06
    mink_solve_hz: float = 30.0
    max_joint_delta: float = SERVING_STEP_BUDGET_RAD
    mink_max_joint_delta: float = SERVING_STEP_BUDGET_RAD
    max_reach: float = 0.8
