"""Independent frozen Axol numerical reference; see the fixture README."""

from __future__ import annotations
import logging
import mink
import mujoco
import numpy as np
from almond_axol.constants import Joint, urdf_body_name
from .ik_config import PINNED_URDF, MinkIKConfig as KinematicsConfig
from .ik_mujoco_model import body_geom_ids, load_mj_model, qpos_indices
_logger = logging.getLogger(__name__)
_ARM_BODY_SUFFIXES = ('s3', 'e1', 'e2', 'w0', 'w1', 'w2', 'gripper')
_TORSO_BODIES = ('base', 's1')
_DELTA_BUDGET = 0.98

class MinkTracker:

    def __init__(self, config: KinematicsConfig, joint_names: list[str], arm_joint_names: list[str], ee_bodies: tuple[str, str], elbow_bodies: tuple[str, str]) -> None:
        self._config = config
        self._model = load_mj_model(PINNED_URDF)
        self._configuration = mink.Configuration(self._model)
        self._q_names = list(joint_names)
        self._qadr = qpos_indices(self._model, self._q_names)
        jids = [mujoco.mj_name2id(self._model, mujoco.mjtObj.mjOBJ_JOINT, n) for n in self._q_names]
        limited = self._model.jnt_limited[jids].astype(bool)
        self._q_lo = np.where(limited, self._model.jnt_range[jids, 0], -np.inf)
        self._q_hi = np.where(limited, self._model.jnt_range[jids, 1], np.inf)
        arm_set = set(arm_joint_names)
        self._frozen_dofs = [int(self._model.jnt_dofadr[j]) for j in range(self._model.njnt) if mujoco.mj_id2name(self._model, mujoco.mjtObj.mjOBJ_JOINT, j) not in arm_set]
        lm = config.mink_lm_damping
        self._ee_tasks = {side: mink.FrameTask(frame_name=name, frame_type='body', position_cost=config.mink_position_cost, orientation_cost=config.mink_orientation_cost, lm_damping=lm) for side, name in zip(('left', 'right'), ee_bodies, strict=True)}
        self._elbow_tasks = {side: mink.FrameTask(frame_name=name, frame_type='body', position_cost=config.mink_elbow_cost, orientation_cost=0.0, lm_damping=lm) for side, name in zip(('left', 'right'), elbow_bodies, strict=True)}
        self._posture_task = mink.PostureTask(self._model, cost=config.mink_posture_cost)
        self._posture_task.set_target(np.zeros(self._model.nq))
        self._gate_scale: float | None = None
        self._last_ee_target: dict[str, np.ndarray | None] = {'left': None, 'right': None}
        data = mujoco.MjData(self._model)
        data.qpos[:] = 0.0
        mujoco.mj_forward(self._model, data)
        self._shoulder_pos = {}
        self._elbow_bid = {}
        self._elbow_radius = {}
        for side, is_left, elbow_body in zip(('left', 'right'), (True, False), elbow_bodies, strict=True):
            sid = mujoco.mj_name2id(self._model, mujoco.mjtObj.mjOBJ_BODY, urdf_body_name(Joint.SHOULDER_1, is_left=is_left))
            eid = mujoco.mj_name2id(self._model, mujoco.mjtObj.mjOBJ_BODY, elbow_body)
            self._shoulder_pos[side] = data.xpos[sid].copy()
            self._elbow_bid[side] = eid
            self._elbow_radius[side] = float(np.linalg.norm(data.xpos[eid] - data.xpos[sid]))
        self._constraints = [mink.DofFreezingTask(self._model, dof_indices=self._frozen_dofs)] if self._frozen_dofs else []
        per_iter_vmax = config.mink_max_joint_delta * _DELTA_BUDGET / (config.mink_iterations * config.mink_dt)
        base_limits: list[object] = [mink.ConfigurationLimit(self._model), mink.VelocityLimit(self._model, dict.fromkeys(arm_joint_names, per_iter_vmax))]
        self._limits = list(base_limits)
        self._limits_no_collision = list(base_limits)
        self.collision_pairs: list[tuple[int, int]] = []
        if config.mink_collision:
            pairs = self._home_feasible_collision_pairs()
            self.collision_pairs = [(a[0], b[0]) for a, b in pairs]
            if pairs:
                self._limits.append(mink.CollisionAvoidanceLimit(self._model, geom_pairs=pairs, minimum_distance_from_collisions=config.mink_collision_min_distance, collision_detection_distance=config.mink_collision_detection_distance))
        self._fail_count = 0

    def _home_feasible_collision_pairs(self) -> list[tuple[list[int], list[int]]]:
        torso = body_geom_ids(self._model, list(_TORSO_BODIES))
        arms = body_geom_ids(self._model, [f'{side}_{sfx}' for side in ('left', 'right') for sfx in _ARM_BODY_SUFFIXES])
        data = mujoco.MjData(self._model)
        data.qpos[:] = 0.0
        mujoco.mj_forward(self._model, data)
        fromto = np.empty(6)
        pairs: list[tuple[list[int], list[int]]] = []
        dropped = 0
        for tg in torso:
            for ag in arms:
                d = mujoco.mj_geomDistance(self._model, data, tg, ag, 1.0, fromto)
                if d <= self._config.mink_collision_min_distance:
                    dropped += 1
                    continue
                pairs.append(([tg], [ag]))
        if dropped:
            _logger.info('mink collision rows: %d torso<->arm geom pairs (%d dropped as infeasible at home)', len(pairs), dropped)
        return pairs

    def set_posture(self, q: np.ndarray) -> None:
        if self._config.mink_posture_target == 'engage':
            self._posture_task.set_target(self._to_qpos(q))

    def reset_tracking_state(self) -> None:
        self._last_ee_target = {'left': None, 'right': None}
        self._gate_scale = None

    @property
    def fail_count(self) -> int:
        return self._fail_count

    def set_rest_posture(self, q: np.ndarray) -> None:
        self._posture_task.set_target(self._to_qpos(q))

    def solve(self, q_current: np.ndarray, left_pose: tuple[np.ndarray, np.ndarray] | None, right_pose: tuple[np.ndarray, np.ndarray] | None, left_elbow_pos: np.ndarray | None, right_elbow_pos: np.ndarray | None) -> np.ndarray:
        cfg = self._config
        self._configuration.update(self._to_qpos(q_current))
        if cfg.mink_posture_speed_gate > 0.0:
            speed = 0.0
            for side, pose in (('left', left_pose), ('right', right_pose)):
                if pose is None:
                    continue
                pos = np.asarray(pose[0], dtype=np.float64)
                last = self._last_ee_target[side]
                if last is not None:
                    speed = max(speed, float(np.linalg.norm(pos - last)) * cfg.mink_solve_hz)
                self._last_ee_target[side] = pos
            scale = 1.0 / (1.0 + (speed / cfg.mink_posture_speed_gate) ** 2)
            if cfg.mink_posture_gate_tau > 0.0:
                if self._gate_scale is None:
                    self._gate_scale = scale
                else:
                    alpha = min(1.0 / cfg.mink_solve_hz / cfg.mink_posture_gate_tau, 1.0)
                    self._gate_scale += alpha * (scale - self._gate_scale)
                scale = self._gate_scale
            self._posture_task.set_cost(cfg.mink_posture_cost * scale)
        tasks: list[object] = [self._posture_task]
        for side, pose in (('left', left_pose), ('right', right_pose)):
            if pose is None:
                continue
            pos, rot = pose
            task = self._ee_tasks[side]
            task.set_target(mink.SE3.from_rotation_and_translation(mink.SO3.from_matrix(np.asarray(rot, dtype=np.float64)), np.asarray(pos, dtype=np.float64)))
            tasks.append(task)
        if cfg.mink_elbow_cost > 0.0:
            for side, hint in (('left', left_elbow_pos), ('right', right_elbow_pos)):
                if hint is None:
                    continue
                center = self._shoulder_pos[side]
                d = np.asarray(hint, dtype=np.float64) - center
                norm = float(np.linalg.norm(d))
                if norm < 0.05:
                    continue
                elbow_now = self._configuration.data.xpos[self._elbow_bid[side]]
                radius = float(np.linalg.norm(elbow_now - center))
                if radius < 0.05:
                    radius = self._elbow_radius[side]
                projected = center + d * (radius / norm)
                task = self._elbow_tasks[side]
                task.set_target(mink.SE3.from_rotation_and_translation(mink.SO3.identity(), projected))
                tasks.append(task)
        for _ in range(cfg.mink_iterations):
            vel = self._solve_step(tasks)
            if vel is None:
                return np.asarray(q_current, dtype=np.float32).copy()
            self._configuration.integrate_inplace(vel, cfg.mink_dt)
        out = np.asarray(q_current, dtype=np.float64).copy()
        out[:len(self._qadr)] = self._configuration.q[self._qadr]
        return out.astype(np.float32)

    def _solve_step(self, tasks: list[object]) -> np.ndarray | None:
        cfg = self._config
        last_exc: Exception | None = None
        for limits in (self._limits, self._limits_no_collision):
            try:
                return mink.solve_ik(self._configuration, tasks, cfg.mink_dt, 'daqp', damping=cfg.mink_damping, safety_break=False, limits=limits, constraints=self._constraints)
            except Exception as exc:
                last_exc = exc
                continue
        self._fail_count += 1
        if self._fail_count == 1 or self._fail_count % 100 == 0:
            _logger.warning('mink solve failed (%d so far), holding last q: %s', self._fail_count, last_exc)
        return None

    def _to_qpos(self, q: np.ndarray) -> np.ndarray:
        qpos = np.zeros(self._model.nq)
        qpos[self._qadr] = np.clip(np.asarray(q, dtype=np.float64)[:len(self._qadr)], self._q_lo, self._q_hi)
        return qpos
