"""Independent frozen Axol numerical reference; see the fixture README."""

from __future__ import annotations
import re
from pathlib import Path
import mujoco
import numpy as np
from .ik_config import PINNED_URDF
_COMPILER_TMPL = '<mujoco><compiler strippath="true" meshdir="{meshdir}" fusestatic="false" discardvisual="true"/></mujoco>'

def load_mj_model(urdf_path: Path=PINNED_URDF) -> mujoco.MjModel:
    text = urdf_path.read_text(encoding='utf-8')
    inject = _COMPILER_TMPL.format(meshdir=str(urdf_path.parent / 'meshes'))
    patched, n = re.subn('(<robot\\b[^>]*>)', '\\1' + inject, text, count=1)
    if n != 1:
        raise ValueError(f'{urdf_path} has no <robot> element to patch')
    return mujoco.MjModel.from_xml_string(patched)

def qpos_indices(model: mujoco.MjModel, joint_names: list[str]) -> np.ndarray:
    return np.array([model.jnt_qposadr[_joint_id(model, n)] for n in joint_names], dtype=int)

def dof_indices(model: mujoco.MjModel, joint_names: list[str]) -> np.ndarray:
    return np.array([model.jnt_dofadr[_joint_id(model, n)] for n in joint_names], dtype=int)

def body_geom_ids(model: mujoco.MjModel, body_names: list[str]) -> list[int]:
    ids: list[int] = []
    for name in body_names:
        bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
        if bid < 0:
            raise KeyError(f'body {name!r} not in model')
        start = model.body_geomadr[bid]
        ids.extend(range(start, start + model.body_geomnum[bid]))
    return ids

def _joint_id(model: mujoco.MjModel, name: str) -> int:
    jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
    if jid < 0:
        raise KeyError(f'joint {name!r} not in model')
    return jid
