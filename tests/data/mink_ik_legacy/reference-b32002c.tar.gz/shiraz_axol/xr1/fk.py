"""Axol BIMANUAL forward kinematics (numpy, stdlib-only) for the XR-1 vendor
conversion pipeline (#345 / #342).

XR-1's action space is EE-relative (local-frame position + axis-angle deltas,
see vendor/xr1/mibot/data/datasets/json_dataset.py:_arm_action), so
the LeRobot->XR-1 converter needs full EE POSES (rotation + position) for BOTH
arms — not just the left-arm position that applications/evaluation/evaluation/
fk.py provides. This module extends that house module to both arms and to full
poses, keeping its conventions bit-identical:

  * EEF link = the URDF ``left_gripper`` / ``right_gripper`` link origin (the
    fixed-jointed gripper body) — the same link the #278 ``_eef`` datasets and
    fk.py use (``urdf_body_name(Joint.GRIPPER, is_left=...)``), NOT ``*_w2``
    and NOT the ``*_hand_tcp`` grasp frame.
  * Root frame = the robot ``root`` link (vendor FLU frame), metres, radians.
  * Joint order per arm = dataset action/state layout dims 0..6 / 8..14:
    shoulder_1, shoulder_2, shoulder_3, elbow, wrist_1, wrist_2, wrist_3.

Chain provenance
----------------
_LEFT_CHAIN is copied VERBATIM from applications/evaluation/evaluation/fk.py
(FK_VERSION fk.axol_urdf_left.numpy.v1), which itself transcribes
third_party/axol/almond_axol/kinematics/urdf/axol.urdf including the ~1e-16
CAD noise. _RIGHT_CHAIN is transcribed the same way from the same URDF
(joints right_s1_0 .. right_w2_0 + fixed right_gripper_0), every origin
xyz/rpy and axis copied unmodified. This v1 frame is part of the existing
XR-1 dataset/checkpoint contract. ``pose_to_current_axol_root`` applies the
new URDF root yaw only at the solver boundary.

Verified in the #345 smoke tests (tests/test_fk_vs_evaluation.py):
  * left-arm positions match applications/evaluation/evaluation/fk.py
    to < 1e-6 m on random joint vectors inside the URDF limits;
  * right-arm poses at the mirrored configuration q_right = -q_left are the
    exact yz-plane mirror of the left poses (x -> -x, R_R = M R_L M), the
    FK-verified axol mirror convention (#342 context report).
"""
# Moved from shiraz experiments/xr1_vendor/axol_fk.py @ e9266d9 (#366): the box
# half of the XR-1 serving split lives in the axol fork — the ZED box tracks
# fork main and has no shiraz checkout.
from __future__ import annotations

import numpy as np

FK_VERSION = "fk.axol_urdf_bimanual.numpy.v1"

# xr1-rustcore: K02 — cherry-picked from fork branch serving/new-axol-main
# (shiraz_axol/xr1/fk.py:44-56). Used ONLY by the R0 frame cross-check test
# (test_xr1_rt_frame_xcheck.py): the serving IK runs on the PINNED fork URDF
# (assets/), so the runtime carries no rotation. Kept here so the relation
# between the v1 checkpoint frame and the chemical-speak URDF is documented
# and fails loudly if the vendor ever changes the arm chain.
# origin of fixed_node_to_root_joint_0; the merged Axol URDF changed only this
# joint's yaw from 0 to +pi/2. Keep the v1 chains below bit-identical for old
# datasets/checkpoints and apply this rigid transform at the actuator boundary.
_AXOL_ROOT_ORIGIN = np.array(
    [-2.77556e-17, -6.93889e-18, 0.86], dtype=np.float64
)
_V1_TO_CURRENT_AXOL_R = np.array(
    [[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]], dtype=np.float64
)

# --------------------------------------------------------------------------- #
# Kinematic chains (transcribed from almond_axol/kinematics/urdf/axol.urdf)
# --------------------------------------------------------------------------- #
# Each entry: (urdf_joint_name, origin_xyz, origin_rpy, axis) — axis None means
# a fixed joint; revolute entries consume q[0..6] in listed order. Child frame
# = parent @ Origin(xyz, rpy) @ Rot(axis, q).

# Copied verbatim from applications/evaluation/evaluation/fk.py (_LEFT_CHAIN).
_LEFT_CHAIN: tuple[tuple[str, tuple, tuple, tuple | None], ...] = (
    ("fixed_node_to_root_joint_0",
     (-2.77556e-17, -6.93889e-18, 0.86), (0.0, -0.0, 0.0), None),
    ("base_0",
     (-2.79001e-17, 6.93889e-18, -0.06), (0.0, -1.06752e-16, 0.0), None),
    ("left_s1_0",
     (0.13, 9.40122e-18, 0.06), (2.77556e-17, -1.02798e-15, 1.32751e-21),
     (-1.0, 0.0, 0.0)),
    ("left_s2_0",
     (0.06958, -0.04475, 4.44089e-16), (2.498e-16, 3.92274e-16, -2.48934e-16),
     (0.0, 1.0, 0.0)),
    ("left_s3_0",
     (-1.91513e-15, 0.04475, -0.07335), (3.33067e-16, -1.05818e-16, -2.03288e-16),
     (0.0, 0.0, 1.0)),
    ("left_e1_0",
     (0.04229, 1.56381e-16, -0.289385), (1.11022e-16, -4.93529e-16, -6.92805e-17),
     (-1.0, 0.0, 2.98117e-16)),
    ("left_e2_0",
     (-0.04229, -1.48698e-17, -0.12429), (-8.32667e-17, -6.33174e-17, 7.22079e-17),
     (0.0, 0.0, 1.0)),
    ("left_w1_0",
     (-5.55112e-17, -0.0285, -0.13567), (-4.71845e-16, 3.45904e-15, -1.18829e-15),
     (0.0, -1.0, 0.0)),
    ("left_w2_0",
     (0.0285, 0.0285, -0.057), (3.4972e-15, -8.32667e-17, -9.70669e-32),
     (-1.0, 0.0, 0.0)),
    ("left_gripper_0",
     (-0.0285, -7.09742e-18, -0.032251), (9.71445e-17, -2.22045e-16, 2.77556e-17),
     None),
)

# Transcribed from the same URDF, right-arm joints, dataset dim order 8..14.
_RIGHT_CHAIN: tuple[tuple[str, tuple, tuple, tuple | None], ...] = (
    ("fixed_node_to_root_joint_0",
     (-2.77556e-17, -6.93889e-18, 0.86), (0.0, -0.0, 0.0), None),
    ("base_0",
     (-2.79001e-17, 6.93889e-18, -0.06), (0.0, -1.06752e-16, 0.0), None),
    ("right_s1_0",
     (-0.13, 2.46215e-18, 0.06), (-4.76873e-49, -2.31296e-16, 7.65788e-33),
     (1.0, 0.0, 0.0)),
    ("right_s2_0",
     (-0.06958, -0.04475, 4.44089e-16), (-1.28654e-32, -9.17877e-18, -7.824e-17),
     (0.0, 1.0, 0.0)),
    ("right_s3_0",
     (3.88578e-16, 0.04475, -0.07335), (-1.08655e-45, -1.28919e-43, -6.16298e-33),
     (0.0, 0.0, 1.0)),
    ("right_e1_0",
     (-0.04229, 1.47751e-17, -0.289385), (1.07561e-45, 7.39557e-32, 1.84889e-32),
     (1.0, 0.0, 2.98117e-16)),
    ("right_e2_0",
     (0.04229, -5.37817e-17, -0.12429), (7.66335e-47, -2.46519e-32, 3.14159),
     (0.0, 0.0, 1.0)),
    ("right_w1_0",
     (1.11022e-16, 0.0285, -0.13567), (1.09476e-47, 2.55312e-94, -4.66423e-47),
     (0.0, 1.0, 0.0)),
    ("right_w2_0",
     (0.0285, -0.0285, -0.057), (-3.73315e-45, -4.43734e-31, 3.14159),
     (1.0, 0.0, 0.0)),
    ("right_gripper_0",
     (0.0285, -7.09742e-18, -0.032251), (0.0, -0.0, 0.0), None),
)


def _rpy_to_R(rpy: tuple) -> np.ndarray:
    """URDF rpy (extrinsic X-Y-Z fixed axes) -> 3x3 rotation: Rz @ Ry @ Rx."""
    r, p, y = (float(v) for v in rpy)
    cr, sr = np.cos(r), np.sin(r)
    cp, sp = np.cos(p), np.sin(p)
    cy, sy = np.cos(y), np.sin(y)
    Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
    Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
    Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def _axis_R(axis: tuple, theta: np.ndarray) -> np.ndarray:
    """Rodrigues rotation about a (normalized) axis, batched: (M,) -> (M,3,3)."""
    a = np.asarray(axis, dtype=np.float64)
    a = a / np.linalg.norm(a)
    K = np.array([[0.0, -a[2], a[1]],
                  [a[2], 0.0, -a[0]],
                  [-a[1], a[0], 0.0]])
    s = np.sin(theta)[:, None, None]
    c = np.cos(theta)[:, None, None]
    eye = np.eye(3)[None]
    return eye + s * K[None] + (1.0 - c) * (K @ K)[None]


def _precompute(chain):
    return (
        tuple(_rpy_to_R(rpy) for _, _, rpy, _ in chain),
        tuple(np.asarray(xyz, dtype=np.float64) for _, xyz, _, _ in chain),
        tuple(axis for _, _, _, axis in chain),
    )


_CHAINS = {
    "left": _precompute(_LEFT_CHAIN),
    "right": _precompute(_RIGHT_CHAIN),
}


def gripper_pose_from_joints(joints: np.ndarray, side: str) -> tuple[np.ndarray, np.ndarray]:
    """EE pose of one arm's ``<side>_gripper`` link from 7 joint angles.

    joints: (..., 7) absolute joint radians in dataset order for that arm
            (left = state/action dims 0..6, right = dims 8..14 — pass the raw
            values, NO sign flip: the right chain encodes the URDF convention).
    side:   "left" | "right".

    Returns (R, p): rotations (..., 3, 3) and positions (..., 3) of the
    gripper-link origin in the robot root frame (metres), float64.
    """
    origin_R, origin_p, axes = _CHAINS[side]
    j = np.asarray(joints, dtype=np.float64)
    if j.shape[-1] != 7:
        raise ValueError(f"need exactly 7 joint dims per arm, got {j.shape[-1]}")
    lead = j.shape[:-1]
    q = j.reshape(-1, 7)
    m = q.shape[0]

    R = np.broadcast_to(np.eye(3), (m, 3, 3)).copy()
    p = np.zeros((m, 3))
    qi = 0
    for Ro, po, axis in zip(origin_R, origin_p, axes):
        p += np.einsum("mij,j->mi", R, po)
        R = R @ Ro
        if axis is not None:
            R = R @ _axis_R(axis, q[:, qi])
            qi += 1
    return R.reshape(*lead, 3, 3), p.reshape(*lead, 3)


def bimanual_poses_from_state(vec16: np.ndarray) -> dict[str, np.ndarray]:
    """Both grippers' poses from a 16-dim axol state/action vector batch.

    vec16: (..., 16) — dims 0-6 left joints, 7 left gripper (ignored),
    8-14 right joints, 15 right gripper (ignored).

    Returns dict with float64 arrays:
      left_R (...,3,3), left_p (...,3), right_R (...,3,3), right_p (...,3).
    """
    v = np.asarray(vec16, dtype=np.float64)
    if v.shape[-1] != 16:
        raise ValueError(f"need 16-dim axol vectors, got {v.shape[-1]}")
    lR, lp = gripper_pose_from_joints(v[..., 0:7], "left")
    rR, rp = gripper_pose_from_joints(v[..., 8:15], "right")
    return {"left_R": lR, "left_p": lp, "right_R": rR, "right_p": rp}


# xr1-rustcore: K02 — cherry-picked from fork branch serving/new-axol-main
# (shiraz_axol/xr1/fk.py:166-198); test-only on this branch (see the note at
# _V1_TO_CURRENT_AXOL_R).
def pose_to_current_axol_root(
    rotm: np.ndarray, pos: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Map a checkpoint-v1 absolute pose into the current Axol solver frame.

    The current URDF adds +pi/2 yaw at ``fixed_node_to_root_joint_0`` while
    retaining that joint's translation. Applying the rigid transform here
    keeps FK-derived XR-1 state, training actions, normalizers, and prefixes
    in their original v1 coordinate contract.

    ``rotm`` may have shape ``(..., 3, 3)`` and ``pos`` ``(..., 3)``.
    """
    R = np.asarray(rotm, dtype=np.float64)
    p = np.asarray(pos, dtype=np.float64)
    transformed_R = np.einsum("ij,...jk->...ik", _V1_TO_CURRENT_AXOL_R, R)
    transformed_p = _AXOL_ROOT_ORIGIN + np.einsum(
        "ij,...j->...i", _V1_TO_CURRENT_AXOL_R, p - _AXOL_ROOT_ORIGIN
    )
    return transformed_R, transformed_p


def pose_from_current_axol_root(
    rotm: np.ndarray, pos: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Map a current Axol solver pose back into checkpoint-v1 space."""
    R = np.asarray(rotm, dtype=np.float64)
    p = np.asarray(pos, dtype=np.float64)
    inverse = _V1_TO_CURRENT_AXOL_R.T
    transformed_R = np.einsum("ij,...jk->...ik", inverse, R)
    transformed_p = _AXOL_ROOT_ORIGIN + np.einsum(
        "ij,...j->...i", inverse, p - _AXOL_ROOT_ORIGIN
    )
    return transformed_R, transformed_p
